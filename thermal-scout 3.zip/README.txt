THERMAL SCOUT — install on iPhone

1. On a computer, open https://app.netlify.com/drop (free account).
2. Unzip thermal-scout.zip and drag the whole "thermal-scout" folder onto the page.
3. Netlify gives you a web address like https://something.netlify.app. Open it in Safari on your iPhone.
4. Tap Share › Add to Home Screen. It now opens full-screen like an app.
5. First launch: allow Location. In Setup, tap "Enable compass" and "Keep screen on".

Alternatives to Netlify: GitHub Pages or Cloudflare Pages. The app must be served over https
for GPS and compass to work; opening index.html straight from Files will not work.

HOW IT WORKS
- Pulls a 9 x 9 grid (32 km square around you) of hourly forecast data from Open-Meteo
  (free, no key; Met Office UKV model over the UK): solar radiation, boundary-layer depth,
  temperature/dew point, low cloud, CAPE, wind at the surface and at 850 hPa.
- Samples terrain 600 m around each cell to get slope and aspect, then works out how
  squarely the sun hits it at that hour.
- Thermal strength: Deardorff convective velocity w* = (g/T · Q · zi)^(1/3), where Q comes
  from sun-on-slope heating and zi is the mixing depth. Expected climb = w* minus 0.9 m/s
  circling sink.
- Cumulus base = 125 m per °C of temperature/dew-point spread. Usable top = lower of cloud
  base and mixing depth.
- Score (0–100) blends climb, usable height, cumulus markers, wind shear penalty and
  overdevelopment risk.
- Each thermal is shifted downwind to where its column sits at YOUR current height.
- Reach check: distance / (glide ratio × groundspeed / airspeed), corrected for head- or
  tailwind, against your arrival margin.
- The arrow points to the nearest thermal you can reach with margin (red if none is in reach).

LIMITS
These are model estimates, not observed thermals. Phone GPS altitude can be 20–50 m off;
use manual altimeter height for anything tight. Always fly with a landable field in reach.
